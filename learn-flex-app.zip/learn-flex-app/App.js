import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View } from "react-native";

export default function App() {
  return (
    <View style={styles.container}>
      <View style={[styles.item, { backgroundColor: "#51cf66" }]}>
        <Text>1</Text>
      </View>
      <View style={[styles.item, { backgroundColor: "#fcc419" }]}>
        <Text>2</Text>
      </View>
      <View style={[styles.item, { backgroundColor: "#ff6b6b" }]}>
        <Text>3</Text>
      </View>
      <StatusBar hidden />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: "column", // default
    // flexDirection: "column-reverse",
    // flexDirection: "row",
    // flexDirection: "row-reverse",

    // Main axis alignment
    // justifyContent: "flex-start", // default: items packed at the start
    // justifyContent: "flex-end", // items packed at the end
    justifyContent: "center", // items centred
    // justifyContent: "space-between", // equal space between items; none at edges
    // justifyContent: "space-around", // equal space around items; half-space at edges
    // justifyContent: "space-evenly", // equal space between items and edges

    // Cross axis alignment
    alignItems: "stretch", // default
    // alignItems: "flex-start",
    // alignItems: "flex-end",
    // alignItems: "center",
    backgroundColor: "#fff",
  },
  item: {
    // flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});
