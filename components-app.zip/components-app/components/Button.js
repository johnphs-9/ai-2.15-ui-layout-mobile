import { Pressable, Text, StyleSheet } from "react-native";

function Button({ title, onPress, color = "#4263eb" }) {
  return (
    <Pressable
      onPress={onPress}
      // android_ripple={{ color: "#ccc" }}
      style={({ pressed }) => [
        styles.button,
        { backgroundColor: color, opacity: pressed ? 0.8 : 1 },
      ]}
    >
      <Text style={styles.text}>{title}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    alignItems: "center",
  },
  text: {
    color: "#fff",
    fontWeight: "700",
  },
});

export default Button;
