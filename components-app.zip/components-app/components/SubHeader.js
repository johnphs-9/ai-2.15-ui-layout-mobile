import { StyleSheet, Text } from "react-native";

function SubHeader({ title, color = "darkblue" }) {
  return <Text style={[styles.subHeader, { color }]}>{title}</Text>;
}

export default SubHeader;

const styles = StyleSheet.create({
  subHeader: {
    fontSize: 18,
    fontWeight: "600",
    color: "darkblue",
    marginBottom: 10,
  },
});