import { Text, StyleSheet } from "react-native";

function Header({ title, color = "darkblue" }) {
  return (
    <Text style={[styles.header, { color, borderBottomColor: color }]}>
      {title}
    </Text>
  );
}

export default Header;

const styles = StyleSheet.create({
  header: {
    fontSize: 20,
    fontWeight: "700",
    color: "darkblue",
    borderBottomWidth: 1,
    borderBottomColor: "darkblue",
    marginBottom: 20,
    paddingBottom: 5,
  },
});
